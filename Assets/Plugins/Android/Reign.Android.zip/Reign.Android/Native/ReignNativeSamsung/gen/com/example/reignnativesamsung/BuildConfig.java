/** Automatically generated file. DO NOT MODIFY */
package com.example.reignnativesamsung;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}